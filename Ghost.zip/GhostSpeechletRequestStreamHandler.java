package Ghost;

import java.util.HashSet;
import java.util.Set;

import com.amazon.speech.speechlet.lambda.SpeechletRequestStreamHandler;

public final class GhostSpeechletRequestStreamHandler extends SpeechletRequestStreamHandler
{
	private static final Set<String> supportedApplicationIds = new HashSet<String>();
    static
    {
    	supportedApplicationIds.add("amzn1.echo-sdk-ams.app.[amzn1.ask.skill.0aed275f-8d32-4c9f-889b-9b388bd2cc37]");
    }

    public GhostSpeechletRequestStreamHandler()
    {
        super(new GhostSpeechlet(), supportedApplicationIds);
    }
}